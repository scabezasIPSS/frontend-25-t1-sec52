<?php
echo '<p>codigo php</p>';
echo '<hr>';
var_dump($_SERVER);