<?php

include_once '../componentes.php';

// Ejemplo 1: Solicitud GET
// Configura tu token y URL base
$tokenBearer = 'ipss.get'; // ¡Reemplaza con tu token real!
$baseUrl = 'https://www.clinicatecnologica.cl/ipss/tejelanasVivi/api/v1'; // ¡Reemplaza con la URL base de tu API!
$endpointFAQ = $baseUrl . '/faq';
$resultGetFAQ = json_encode(consumeEndpointWithBearer($endpointFAQ, $tokenBearer, 'GET')['data']['data']);

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
</head>

<body>
    <section id="faq" class="container bg-primary">
        <h1 class="text-light p-4 text-center">Preguntas Frecuentes</h1>
        <div class="accordion pb-4" id="accordionPanelsStayOpenExample">
            <div class="text-center">
                <img src="../dist/imgs/loading-primary.gif" alt="">
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.js"
        integrity="sha512-+k1pnlgt4F1H8L7t3z95o3/KO+o78INEcXTbnoJQ/F2VqDVhWoaiVml/OEHv9HsVgxUaVW+IbiZPUJQfF/YxZw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        const datos = <?php echo $resultGetFAQ ?>;

        cargarFAQJS(datos, 'accordionPanelsStayOpenExample');

        function cargarFAQJS(_data, _div) {
            const div = document.getElementById(_div);
            div.innerHTML = '';
            _data.forEach(element => {
                const itemAcordeon = document.createElement('div');
                itemAcordeon.innerHTML = `
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse${element.id}" aria-expanded="false" aria-controls="panelsStayOpen-collapse${element.id}">
                                ${element.titulo}
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapse${element.id}" class="accordion-collapse collapse">
                            <div class="accordion-body">
                                ${element.respuesta}
                            </div>
                        </div>
                    </div>
                `;
                div.appendChild(itemAcordeon);
            });
        }
    </script>
</body>

</html>