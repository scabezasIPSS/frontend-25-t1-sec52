<?php

include_once '../componentes.php';

// Ejemplo 1: Solicitud GET
// Configura tu token y URL base
$tokenBearer = 'ipss.get'; // ¡Reemplaza con tu token real!
$baseUrl = 'https://www.clinicatecnologica.cl/ipss/antiguedadesSthandier/api/v1'; // ¡Reemplaza con la URL base de tu API!
$endpointFAQ = $baseUrl . '/faq';
$resultGetFAQ = json_encode(consumeEndpointWithBearer($endpointFAQ, $tokenBearer, 'GET')['data']['data']);

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <style>
        .accordion-button:not(.collapsed) {
            color: black !important;
            background-color: gold !important;
            box-shadow: inset 0 calc(-1 * gold) 0 gold !important;
        }
    </style>
</head>

<body>
    <section id="faq" class="container bg-secondary">
        <h1 class="text-light p-4 text-center">Preguntas Frecuentes</h1>
        <div class="accordion pb-4" id="accordionPanelsStayOpenExample">
            <div class="text-center">
                <img src="../dist/imgs/loading-primary.gif" alt="">
            </div>
        </div>
    </section>
    <section class="container bg-danger">
        <h1 class="text-light p-4 text-center">Contacto</h1>
        <div class="row pb-4">
            <div class="col-6">Imagen... o informacion x...</div>
            <div class="col-6">
                <input type="text" class="form-control col-12 mb-2" id="formNombre" value="Sebastian">
                <input type="email" id="formEmail" class="form-control col-12 mb-2" value="sebastian.cabezas@docente.ipss.cl">
                <input type="tel" id="formTelefono" class="form-control col-12 mb-2" value="+56912341234">
                <textarea id="formMensaje" rows="10" class="form-control col-12 mb-2"></textarea>
                <button class="btn btn-primary" onclick="enviarMensajePorWhatsapp()">Enviar Mensaje</button>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.js"
        integrity="sha512-+k1pnlgt4F1H8L7t3z95o3/KO+o78INEcXTbnoJQ/F2VqDVhWoaiVml/OEHv9HsVgxUaVW+IbiZPUJQfF/YxZw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        
        function enviarMensajePorWhatsapp() {
            const nombre = document.getElementById('formNombre').value;
            const email = document.getElementById('formEmail').value;
            const tel = document.getElementById('formTelefono').value;
            const mensaje = document.getElementById('formMensaje').value;

            // Codifica el mensaje para asegurar que caracteres especiales se interpreten correctamente en la URL.
            // Los corchetes en el email también deben ser codificados si no quieres que WhatsApp los interprete como URL.
            // Si quieres que el email sea un enlace clicable en WhatsApp, podrías dejarlo sin codificar o usar un formato de enlace Markdown.
            const mensajeDeEnvioCrudo = `Hola ${nombre}! nos comunicaremos contigo al teléfono: ${tel} o al correo electrónico ${email} si no contestas. Nos importa mucho tu mensaje: ${mensaje}. Gracias!`;
            const mensajeCodificado = encodeURIComponent(mensajeDeEnvioCrudo);

            const numeroDestino = '+56912341234'; // Asegúrate de que este número incluya el código de país.
            const waMe = `https://wa.me/${numeroDestino}?text=${mensajeCodificado}`;

            // Redirecciona a la página de WhatsApp o abre una nueva pestaña.
            // '_blank' abre el enlace en una nueva pestaña.
            window.open(waMe, '_blank');
        }

        const datos = <?php echo $resultGetFAQ ?>;

        cargarFAQJS(datos, 'accordionPanelsStayOpenExample');

        function cargarFAQJS(_data, _div) {
            const div = document.getElementById(_div);
            div.innerHTML = '';
            _data.forEach(element => {
                const itemAcordeon = document.createElement('div');
                itemAcordeon.innerHTML = `
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse${element.id}" aria-expanded="false" aria-controls="panelsStayOpen-collapse${element.id}">
                                ${element.titulo}
                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapse${element.id}" class="accordion-collapse collapse">
                            <div class="accordion-body">
                                ${element.respuesta}
                            </div>
                        </div>
                    </div>
                `;
                div.appendChild(itemAcordeon);
            });
        }
    </script>
</body>

</html>